<?php

declare(strict_types=1);

namespace inviser\Task\TaskFal;

use inviser\Main;
use pocketmine\item\Item;
use pocketmine\scheduler\Task;
use pocketmine\entity\Effect;
use pocketmine\entity\EffectInstance;

class FalseTask extends Task{
    
    public function onRun(int $tick) : void{
        foreach(Main::getInstance()->getServer()->getOnlinePlayers() as $players){
            $inv = $players->getInventory();
            $item = $inv->getItemInHand();
            if ($item->getCustomName() == "§aFrequent§eInviser\nInvisibleDenganLeatherChestplate\n§oTidakTerlihat\n§oPluginByAnjayMabar\n§oNomer:08573936813" && $item->getEnchantment(238)){
            switch($item->getId()){
                case 299:
                    if($item->getId() === Item::LEATHER_CHESTPLATE){
                    	$players->setNameTagVisible(true);
                    }else{
                 $players->setNameTagVisible(true);
                 return;
                 }
                 }
           }
   }
 }
 }
