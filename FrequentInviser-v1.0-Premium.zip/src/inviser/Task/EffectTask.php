<?php

declare(strict_types=1);

namespace inviser\task;

use inviser\Main;
use pocketmine\item\Item;
use pocketmine\scheduler\Task;
use pocketmine\entity\Effect;
use pocketmine\entity\EffectInstance;

class EffectTask extends Task{
    
    public function onRun(int $tick) : void{
        foreach(Main::getInstance()->getServer()->getOnlinePlayers() as $players){
            $inv = $players->getArmorInventory();
            $helmet = $inv->getChestplate();
            $m = $players->getInventory();
            if ($helmet->getCustomName() == "§aFrequent§eInviser\nInvisibleDenganLeatherChestplate\n§oTidakTerlihat\n§oPluginByAnjayMabar\n§oNomer:08573936813" && $helmet->getEnchantment(238)){
            switch($helmet->getId()){
                case 299:
                    $players->addEffect(new EffectInstance(Effect::getEffect(Effect::HEALTH_BOOST), 220, 2, false));
                    if($helmet->getId() === Item::LEATHER_CHESTPLATE){
                    	$players->setNameTagVisible(false);
                    }else{
                 $players->setNameTagVisible(true);
                 return;
                 }
                 }
           }
   }
 }
 }
