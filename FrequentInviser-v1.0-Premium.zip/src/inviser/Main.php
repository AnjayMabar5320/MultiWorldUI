<?php

namespace inviser;

use pocketmine\Server;
use pocketmine\plugin\PluginBase;
use pocketmine\event\Listener;
use inviser\Task\EffectTask;
use inviser\Task\TaskFal\FalseTask;

use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\event\player\PlayerJoinEvent;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\event\entity\EntityLevelChangeEvent;
use pocketmine\event\player\PlayerMoveEvent;
use pocketmine\entity\Effect;

use pocketmine\Player;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\command\CommandExecutor;
use pocketmine\command\ConsoleCommandSender;

use DaPigGuy\PiggyCustomEnchants\enchants\CustomEnchantIds;
use DaPigGuy\PiggyCustomEnchants\PiggyCustomEnchants;
use pocketmine\item\Item;
use pocketmine\lang\BaseLang;
use pocketmine\item\enchantment\Enchantment;
use pocketmine\item\enchantment\EnchantmentInstance;
use pocketmine\block\Block;
use pocketmine\math\Vector3;
use pocketmine\utils\TextFormat;
use pocketmine\utils\Config;

use onebone\economyapi\EconomyAPI;

use jojoe77777\FormAPI;

class Main extends PluginBase implements Listener {
    
    /** @var Main $instance */
    private static $instance;
	
	public $plugin;

	public function onEnable() : void{
	    self::$instance = $this;
	    $this->getScheduler()->scheduleRepeatingTask(new EffectTask(), 20);
	    $this->getScheduler()->scheduleRepeatingTask(new FalseTask(), 20);
        $this->getLogger()->info(TextFormat::GREEN . "FrequentInviser By AnjayMabar Aktif
		
		_________  _
		l ______l l_l
		l l        _
		l l______ l l
		l  _____l l l
		l l       l l
		l l       l l
		l l       l l
		l l       l l
		l_l       l_l
		
		
		");
        $this->eco = $this->getServer()->getPluginManager()->getPlugin("EconomyAPI");	
	}
	
	public static function getInstance() : self{
	    return self::$instance;
	}
 
 
 public function onCommand(CommandSender $sender, Command $cmd, string $label, array $args) : bool {
        switch($cmd->getName()){                    
            case "fi":
                if($sender instanceof Player){
                    if($sender->hasPermission("fi.item")){
                        $fi = Item::get(299, 0, 1)->setCustomName("§aFrequent§eInviser\nInvisibleDenganLeatherChestplate\n§oTidakTerlihat\n§oPluginByAnjayMabar\n§oNomer:08573936813"); 
                        $ec = Enchantment::getEnchantment(238);
                        $ech = new EnchantmentInstance($ec);
                        $fi->addEnchantment($ech);
                        $sender->getInventory()->addItem($fi);
                        $sender->addTitle("§aKamu diberikan\nLeather Chestplate Untuk Tak Terlihat");
                        return true;
                    }else{
                        $sender->sendMessage("§cMembutuh Kan Permissions!");
                        return true;
                    }

                }else{
                    $sender->sendMessage("§cGunakan Command Dalam Game!");
                    return true;
                }  
        }
      }
    }
    