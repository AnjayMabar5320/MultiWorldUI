<?php

declare(strict_types=1);

namespace AnjayMabar\EconomyUI;

use pocketmine\utils\Config;
use pocketmine\event\Listener;
use pocketmine\plugin\PluginBase;
use AnjayMabar\EconomyUI\Main;

class Ecoui extends PluginBase implements Listener {

	public function onEnable(){
		@eval(base64_decode("JHRoaXMtPmdldExvZ2dlcigpLT5ub3RpY2UoInBsdWdpbiBjcmVhdGUgYnkgYnVtYnVta2lsbCIpOw=="));
		$this->getServer()->getCommandMap()->register("ecoui", new Main($this));
	}
}
