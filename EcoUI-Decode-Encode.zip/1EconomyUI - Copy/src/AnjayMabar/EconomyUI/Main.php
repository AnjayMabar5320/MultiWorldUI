<?php

namespace AnjayMabar\EconomyUI;

use jojoe77777\FormAPI\FormAPI;

use onebone\economyapi\EconomyAPI;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\command\PluginIdentifiableCommand;

use pocketmine\Player;
use pocketmine\plugin\Plugin;

use pocketmine\utils\Config;
use pocketmine\utils\TextFormat as C;

class Main extends Command implements PluginIdentifiableCommand{
	
	public function getPlugin() : Plugin{
		return true;
	}
	
	private $main;
	
	public function __construct(Loader $main){
		$this->main = $main;
		parent::__construct("economyui", "EconomyUI Menu", "/ecoui", ["ecui", "ecoui", "eui"]);
	}
	
	public function execute(CommandSender $sender, string $label, array $args){
		if(!$sender instanceof Player){
			$sender->sendMessage("§cGunakan Command Dalam Game!");
			return false;
		}
		
		if(!isset($args[0]) || $args[0] !== "op"){
			if($sender->hasPermission("ecoui.use.plyr")){
				$this->memberForm($sender);
				return true;
			}else{
				$sender->sendMessage("§eKamu Tidak Memiliki Izin Untuk Menggunakan Command ini!");
				return false;
			}
		}
		
		if($args[0] === "op"){
			if($sender->hasPermission("ecoui.use.op")){
				$this->opForm($sender);
			}else{
				$sender->sendMessage("§cKamu Bukan Staff Goblok!");
				return false;
			}
		}
		return false;
	}
	
	public function memberForm(Player $sender){
		$api = $this->main->getServer()->getPluginManager()->getPlugin("FormAPI");
		$form = $api->createSimpleForm(function(Player $sender, ?int $data){
			if(!isset($data)) return;
			switch($data){
				case 0:
				    $this->mymoney($sender);
				break;
				case 1:
				    $this->seemoney($sender);
				break;
				case 2:
				    $this->pay($sender);
				break;
				case 3:
				    $this->topmoney($sender);
				break;
			}
		});
		$name = $sender->getName();
		$form->setTitle(C::GREEN . "EconomyUI");
		$form->setContent("§bHay §a$name. §eSelamat Datang DiEconomyUI\n\n§6Silahkan Pilih Yang Ingin Kamu Lakukan\n\n\n\n:");
		$form->addButton(C::YELLOW . "Uangku");
		$form->addButton(C::AQUA . "Lihat Uang Pemain");
		$form->addButton(C::BLUE . "Bayar");
		$form->addButton(C::GOLD . "Top Money");
		$form->addButton(C::RED . "KELUAR");
	}
	
	public function mymoney(Player $sender){
		$api = $this->main->getServer()->getPluginManager()->getPlugin("FormAPI");
		$f = $api->createCustomForm(function(Player $sender, ?array $data){
	    });
		$economy = EconomyAPI::getInstance();
        $mny = $economy->myMoney($sender);
		$f->setTitle(T::GREEN . "EconomyUI");
		$f->addLabel(T::YELLOW . "Uangmu: $mny");
		$f->sendToPlayer($sender);
	}
	
	public function seemoney(Player $player){
		$api = $this->main->getServer()->getPluginManager()->getPlugin("FormAPI");
		$f = $api->createCustomForm(function(Player $player, ?array $data){
			if(!isset($data)) return;
			if($this->main->getServer()->getOfflinePlayer($data[0])->hasPlayedBefore() || $this->main->getServer()->getOfflinePlayer($data[0])->isOnline() && EconomyAPI::getInstance()->myMoney($data[0]) !== null){
				$this->seeForm($player, $data[0]);
			}else{
				$player->sendMessage(T::RED . "Pemain Tidak Aktif");
			}
		});
		$f->setTitle(T::GREEN . "EconomyUI");
		$f->addInput("Nama Pemain", "AnjayMabar5320");
		$f->sendToPlayer($player);
	}
	
	public function seeForm(Player $player, string $player1){
		$api = $this->main->getServer()->getPluginManager()->getPlugin("FormAPI");
		$f = $api->createCustomForm(function(Player $player, ?array $data){
		});
		$economy = EconomyAPI::getInstance();
        $mny = $economy->myMoney($player1);
		$f->setTitle(T::GREEN . "EconomyUI");
		$f->addLabel(T::YELLOW . "Uang Dia Ada: $mny/n");
		$f->sendToPlayer($player);
	}
	
	public function pay(Player $sender){
		$api = $this->main->getServer()->getPluginManager()->getPlugin("FormAPI");
		$f = $api->createCustomForm(function(Player $sender, ?array $data){
			if(!isset($data)) return;
			$this->main->getServer()->getCommandMap()->dispatch($sender, "pay $data[0] $data[1]");
	    });
		$f->setTitle(T::GREEN . "EconomyUI");
		$f->addInput("Nama Pemain", "AnjayMabar5320");
        $f->addInput("Jumlah", "1000");
		$f->sendToPlayer($sender);
	}
	
	public function topmoney(Player $player){
		$money = $this->main->getServer()->getPluginManager()->getPlugin("EconomyAPI");
		$money_top = $money->getAllMoney();
		$message = "";
		if(count($money_top) > 0){
			arsort($money_top);
			$i = 1;
			foreach($money_top as $name => $money){
				$message .= "  §f".$i.". §e".$name.":    §bRP.".$money."."."\n";
				if($i >= 10){
					break;
				}
				++$i;
			}
		}
		$api = $this->main->getServer()->getPluginManager()->getPlugin("FormAPI");
		$form = $api->createSimpleForm(function (Player $player, int $data = null){
			$result = $data;
			if($result === null){
				return true;
			}
			switch($result){
				case "0";
				    $command = "ecoui" ;
                    $this->getServer()->getCommandMap()->dispatch($sender, $command);
				break;
			}
		});
		$form->setTitle($this->getConfig()->get("TopMoney-Title"));
		$form->setContent("".$message);
	    $form->addButton(§e"Kembali", 0, "textures/ui/cancel");
		$form->sendToPlayer($player);
		return $form;
	}
	
	public function opForm(Player $sender){
		$api = $this->main->getServer()->getPluginManager()->getPlugin("FormAPI");
		$form = $api->createSimpleForm(function(Player $sender, ?int $data){
			if(!isset($data)) return;
			switch($data){
				case 0:
				    $this->reduce($sender);
				break;
				case 1:
				    $this->add($sender);
				break;
				case 2:
				    $this->set($sender);
				break;
				case 3:
				
				break;
			}
		});
		$name = $sender->getName();
		$form->setTitle(C::GREEN . "EconomyUI");
		$form->setContent("§bHay Staff §a$name.\n\n§6Silahkan Pilih Yang Ingin Kamu Lakukan\n\n\n\n:");
		$form->addButton(C::YELLOW . "Ambil Uang Pemain");
		$form->addButton(C::AQUA . "Beri Uang kePemain");
		$form->addButton(C::BLUE . "Set Uang Pemain");
		$form->addButton(C::RED . "KELUAR");
	}
	
	public function reduce(Player $sender){
		$api = $this->main->getServer()->getPluginManager()->getPlugin("FormAPI");
		$f = $api->createCustomForm(function(Player $sender, ?array $data){
			if(!isset($data)) return;
			$this->main->getServer()->getCommandMap()->dispatch($sender, "takemoney $data[0] $data[1]");
	    });
		$f->setTitle(T::GREEN . "EconomyUI");
		$f->addInput("Nama Pemain", "AnjayMabar5320");
        $f->addInput("Jumlah", "1000");
		$f->sendToPlayer($sender);
	}
	
	public function add(Player $sender){
		$api = $this->main->getServer()->getPluginManager()->getPlugin("FormAPI");
		$f = $api->createCustomForm(function(Player $sender, ?array $data){
			if(!isset($data)) return;
			$this->main->getServer()->getCommandMap()->dispatch($sender, "givemoney $data[0] $data[1]");
	    });
		$f->setTitle(T::GREEN . "EconomyUI");
		$f->addInput("Nama Pemain", "AnjayMabar5320");
        $f->addInput("Jumlah", "1000");
		$f->sendToPlayer($sender);
	}
	
	public function set(Player $sender){
		$api = $this->main->getServer()->getPluginManager()->getPlugin("FormAPI");
		$f = $api->createCustomForm(function(Player $sender, ?array $data){
			if(!isset($data)) return;
			$this->main->getServer()->getCommandMap()->dispatch($sender, "setmoney $data[0] $data[1]");
	    });
		$f->setTitle(T::GREEN . "EconomyUI");
		$f->addInput("Nama Pemain", "AnjayMabar5320");
        $f->addInput("Jumlah", "1000");
		$f->sendToPlayer($sender);
	}
	
	
	
	
	
	
	
	
	
}