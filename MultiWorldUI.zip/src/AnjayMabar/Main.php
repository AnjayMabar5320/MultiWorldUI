<?php

/**
*    ^
*     ╔══════════╗  ╔══════════╗
*     ║          ║  ║  ╔═══════╝
*     ║  ╔════╗  ║  ║  ║           
*     ║  ║    ║  ║  ║  ║          AnjayMabar5320
*     ║  ╚════╝  ║  ║  ╚═══════╗  Discord: PedhotSpijikun#0275
*     ║  ╔════╗  ║  ║  ╔════╗  ║  Github: PedhotNoob(MinionID)
*     ║  ║    ║  ║  ║  ║    ║  ║
*     ║  ║    ║  ║  ║  ╚════╝  ║ 
*     ╚══╝    ╚══╝  ╚══════════╝
*/

namespace AnjayMabar;

use pocketmine\Player; 
use pocketmine\Server;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerJoinEvent;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\item\Item;
use pocketmine\event\block\BlockPlaceEvent;
use pocketmine\item\enchantment\Enchantment;
use pocketmine\item\enchantment\EnchantmentInstance;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\block\Block;
use pocketmine\math\Vector3;
use pocketmine\level\particle\DestroyBlockParticle;
use pocketmine\level\particle\{DustParticle, FlameParticle, FloatingTextParticle, EntityFlameParticle, CriticalParticle, ExplodeParticle, HeartParticle, LavaParticle, MobSpawnParticle, SplashParticle};
use pocketmine\event\player\PlayerMoveEvent;
use jojoe77777\FormAPI\FormAPI;
use onebone\economyapi\EconomyAPI;

class Main extends PluginBase implements Listener{
	
	public function onCommand(CommandSender $sender, Command $command, string $label, array $args) : bool{
        $player = $sender->getPlayer();
        switch($command->getName()){
            case "mwui":
                $this->home($player);
        }
        return true;
    }
	
	public function home(Player $player){
        if($player instanceof Player){
            $api = $this->getServer()->getPluginManager()->getPlugin("FormAPI");
            $form = $api->createSimpleForm(function (Player $sender, array $data){
                if(isset($data[0])){
                    switch($data[0]){
                        case 0:
                            //Create a World
                            $this->createWorldForm($sender);
                            break;
                        case 1:
                            //List a World
                            Server::getInstance()->dispatchCommand($sender,'mw list')
                            break;
                        case 2:
                            //Delete World
                            $this->deleteWorldForm($sender);
                            break;
                        case 3:
                            //Teleport a World
                            $this->teleportWorldForm($sender);
                            break;
						case 4:
                            //Load World
                            $this->loadWorldForm($sender);
                            break;
                        case 5:
                            //Rename a World
                            $this->renameWorldForm($sender);
                            break;
						case 6:
						    Server::getInstance()->dispatchCommand($sender,'mw manage')
						    break;
                    }
                }
            });
			$name = $sender->getName();
			$world = $sender->getLevel()->getName();
			$location = count($sender->getLevel()->getPlayers());
            $form->setTitle("§bMulti§cWorld§aUI");
            $form->setContent("§eHay, §f{$name}\n§bKamu Sekarang Berada di§a{$world}. §bDi§a{$world} §bAda §c{$location} §bPemain");
            $form->addButton("§aBuat World", 0, "textures/ui/color_plus");
            $form->addButton("§aList World", 0, "textures/ui/mashub_world");
            $form->addButton("§aHapus World", 0, "textures/ui/trash");
            $form->addButton("§aTeleport World", 0, "textures/ui/mashub_world");
			$form->addButton("§aLoad World", 0, "textures/ui/mashub_world");
            $form->addButton("§aRename World", 0, "textures/ui/mashub_world");
            $form->addButton("§aManage World", 0, "textures/ui/mashub_world");
            $form->addButton("§cKeluar", 0, "textures/ui/realms_red_x");
            $form->sendToPlayer($sender);
			return $form;
        }
    }
	
	public function createWorldForm(Player $sender){
        $api = $this->main->getServer()->getPluginManager()->getPlugin("FormAPI");
        $f = $api->createCustomForm(function(Player $sender, ?array $data){
            if(!isset($data)) return;
			$this->main->getServer()->getCommandMap()->dispatch($sender, "mw create $data[0] $data[1] $data[2]");
        });
		
        $f->setTitle("§bMulti§cWorld§aUI");
		$f->addInput("Nama World", "Survival");
        $f->addInput("Seed", "0");
		$f->addInput("Type", "flat");
		$f->sendToPlayer($sender);
		return $form;
    }
	
	public function deleteWorldForm(Player $sender){
        $api = $this->main->getServer()->getPluginManager()->getPlugin("FormAPI");
        $f = $api->createCustomForm(function(Player $sender, ?array $data){
            if(!isset($data)) return;
			$this->main->getServer()->getCommandMap()->dispatch($sender, "mw delete $data[0]");
        });
		
        $f->setTitle("§bMulti§cWorld§aUI");
		$f->addInput("Nama World", "Survival");
		$f->sendToPlayer($sender);
		return $form;
    }
	
	public function teleportWorldForm(Player $sender){
        $api = $this->main->getServer()->getPluginManager()->getPlugin("FormAPI");
        $f = $api->createCustomForm(function(Player $sender, ?array $data){
            if(!isset($data)) return;
			$this->main->getServer()->getCommandMap()->dispatch($sender, "mw delete $data[0]");
        });
		
        $f->setTitle("§bMulti§cWorld§aUI");
		$f->addInput("Nama World", "Survival");
		$f->sendToPlayer($sender);
		return $form;
    }
	
	public function loadWorldForm(Player $sender){
        $api = $this->main->getServer()->getPluginManager()->getPlugin("FormAPI");
        $f = $api->createCustomForm(function(Player $sender, ?array $data){
            if(!isset($data)) return;
			$this->main->getServer()->getCommandMap()->dispatch($sender, "mw load $data[0]");
        });
		
        $f->setTitle("§bMulti§cWorld§aUI");
		$f->addInput("Nama World", "Survival");
		$f->sendToPlayer($sender);
		return $form;
    }
	
	public function renameWorldForm(Player $sender){
        $api = $this->main->getServer()->getPluginManager()->getPlugin("FormAPI");
        $f = $api->createCustomForm(function(Player $sender, ?array $data){
            if(!isset($data)) return;
			$this->main->getServer()->getCommandMap()->dispatch($sender, "mw rename $data[0] $data[1]");
        });
		
        $f->setTitle("§bMulti§cWorld§aUI");
		$f->addInput("Nama Lama", "Survival");
		$f->addInput("Nama Baru", "Lobby");
		$f->sendToPlayer($sender);
		return $form;
    }
	
	
	
	
	
	
	
	
	
}
